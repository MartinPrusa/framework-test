//
//  MartinRocks.h
//  MartinRocks
//
//  Created by Martin Prusa on 4/13/18.
//  Copyright © 2018 BSC Ideas. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MartinRocks.
FOUNDATION_EXPORT double MartinRocksVersionNumber;

//! Project version string for MartinRocks.
FOUNDATION_EXPORT const unsigned char MartinRocksVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MartinRocks/PublicHeader.h>


